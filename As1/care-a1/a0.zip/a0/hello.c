
//.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-
// Source by Hello World Domination Inc.
//.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-

#include <stdio.h>

void main () {
	puts("Hello world!");
}
